# IBM Z, watsonx, and Demo Help update

This update adds the IBM Z Enterprise Security Integration panel to the console, with three cards (IBM Z, Random Forest ML, IBM watsonx), an Integration Roadmap, and a Help & Support modal.

## Status accuracy
- IBM Z: Integration planned. No mainframe data source is connected by this UI update.
- Random Forest ML: Reflects backend/model availability when the API reports it; otherwise asks the user to check backend/model status.
- IBM watsonx: Not connected. The card describes potential future threat explanations and security recommendations only.

A real watsonx integration requires an IBM watsonx.ai service endpoint, project/space ID, IBM Cloud API key, backend-side authentication, and a configured model. Keep credentials on the backend in environment variables; do not put secrets in React code. See IBM's watsonx getting started documentation: https://www.ibm.com/docs/en/watsonx/saas?topic=getting-started-tutorials

## Frontend build
Run `npm install` and `npm run build` from the project root. This environment did not have the npm dependencies installed, so a Vite production build could not be run here. The App.jsx source was updated and saved.
