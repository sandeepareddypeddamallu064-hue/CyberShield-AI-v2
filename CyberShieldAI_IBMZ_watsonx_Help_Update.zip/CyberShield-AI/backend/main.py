from datetime import datetime, timezone
from pathlib import Path
import json
import sqlite3

import joblib
import pandas as pd

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel


# --------------------------------------------------
# 1. APPLICATION SETUP
# --------------------------------------------------

app = FastAPI(
    title="CyberShield AI API",
    description="Security event monitoring and ML-based threat detection",
    version="1.2.1",
)


# --------------------------------------------------
# 2. CORS CONFIGURATION
# --------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "https://stately-pastelito-d53cf3.netlify.app",
        "https://shiny-sable-775251.netlify.app",
        "https://cybershield-ai-beats.netlify.app",
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------
# 3. PROJECT PATHS AND DATABASE
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

MODEL_DIR = BASE_DIR / "ml" / "models"
MODEL_PATH = MODEL_DIR / "cybershield_model.joblib"
FEATURE_PATH = MODEL_DIR / "feature_names.joblib"
DATABASE_PATH = BASE_DIR / "cybershield.db"


def initialize_database():
    """Create the prediction-history table if it does not exist."""

    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prediction TEXT NOT NULL,
                is_attack INTEGER NOT NULL,
                confidence REAL NOT NULL,
                severity TEXT NOT NULL,
                risk_score INTEGER NOT NULL,
                model TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
            """
        )
        connection.commit()


initialize_database()
print(f"Prediction database ready: {DATABASE_PATH}")


# --------------------------------------------------
# 4. LOAD THE USER'S TWO-STAGE CYBERSHIELD MODELS
# --------------------------------------------------

BINARY_MODEL_PATH = MODEL_DIR / "cybershield_cross_day_model.joblib"
THREAT_MODEL_PATH = MODEL_DIR / "cybershield_threat_classifier.joblib"

binary_bundle = None
threat_bundle = None
binary_model = None
threat_model = None
feature_names = None
threat_classes = []

try:
    if BINARY_MODEL_PATH.exists() and THREAT_MODEL_PATH.exists():
        binary_bundle = joblib.load(BINARY_MODEL_PATH)
        threat_bundle = joblib.load(THREAT_MODEL_PATH)
        binary_model = binary_bundle["model"]
        threat_model = threat_bundle["model"]
        feature_names = list(binary_bundle["feature_names"])
        threat_classes = list(threat_bundle["classes"])

        if feature_names != list(threat_bundle["feature_names"]):
            raise ValueError("Binary and threat models have different feature orders.")

        print(f"CyberShield binary model loaded ({len(feature_names)} features).")
        print(f"CyberShield threat classifier loaded ({len(threat_classes)} classes).")
    else:
        print("WARNING: Two-stage models not found in ml/models.")
except Exception as exc:
    print(f"WARNING: Could not load CyberShield models: {exc}")


# --------------------------------------------------
# 5. HELPER FUNCTIONS
# --------------------------------------------------

def calculate_risk_score(severity: str) -> int:
    risk_scores = {
        "Critical": 95,
        "High": 80,
        "Medium": 55,
        "Low": 25,
    }

    return risk_scores.get(severity.capitalize(), 55)


def save_prediction(result: dict) -> int:
    """Save a successful model prediction and return its database ID."""

    with sqlite3.connect(DATABASE_PATH) as connection:
        cursor = connection.execute(
            """
            INSERT INTO predictions (
                prediction,
                is_attack,
                confidence,
                severity,
                risk_score,
                model,
                timestamp
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result["prediction"],
                int(result["is_attack"]),
                result["confidence"],
                result["severity"],
                result["risk_score"],
                result["model"],
                result["timestamp"],
            ),
        )

        connection.commit()

        return cursor.lastrowid


# --------------------------------------------------
# 6. REQUEST MODELS
# --------------------------------------------------

class SecurityEvent(BaseModel):
    event_type: str
    source_ip: str
    description: str
    severity: str = "Medium"


class PredictionRequest(BaseModel):
    features: dict[str, float]


# --------------------------------------------------
# 7. SECURITY EVENT STORAGE
# --------------------------------------------------

# Events reset when the backend restarts.
# Prediction history is stored in SQLite.

events = []


# --------------------------------------------------
# 8. BASIC ENDPOINTS
# --------------------------------------------------

@app.get("/")
def home():
    return {
        "message": "CyberShield AI backend is running!",
        "status": "online",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "model_loaded": binary_model is not None and threat_model is not None,
        "binary_model_loaded": binary_model is not None,
        "threat_classifier_loaded": threat_model is not None,
        "feature_count": len(feature_names) if feature_names else 0,
        "threat_classes": threat_classes,
        "database_path": str(DATABASE_PATH),
    }


# --------------------------------------------------
# 9. GET SECURITY EVENTS
# --------------------------------------------------

@app.get("/api/events")
def get_events():
    return {
        "total": len(events),
        "events": events,
    }


# --------------------------------------------------
# 10. CREATE SECURITY EVENT
# --------------------------------------------------

@app.post("/api/events")
def create_event(event: SecurityEvent):
    new_event = event.model_dump()

    new_event["id"] = len(events) + 1
    new_event["timestamp"] = datetime.now(timezone.utc).isoformat()
    new_event["risk_score"] = calculate_risk_score(
        new_event["severity"]
    )

    events.insert(0, new_event)

    return {
        "message": "Security event received",
        "event": new_event,
    }


# --------------------------------------------------
# 11. MACHINE LEARNING PREDICTION
# --------------------------------------------------

@app.get("/api/model-info")
def model_info():
    return {
        "binary_model_loaded": binary_model is not None,
        "threat_model_loaded": threat_model is not None,
        "feature_count": len(feature_names) if feature_names else 0,
        "feature_names": feature_names or [],
        "binary_threshold": float(binary_bundle.get("threshold", 0.1)) if binary_bundle else 0.1,
        "supported_threat_classes": [str(value) for value in getattr(threat_model, "classes_", [])],
    }


@app.post("/api/predict")
def predict_attack(request: PredictionRequest):
    """Run binary attack detection, then classify flagged traffic."""

    if binary_model is None or threat_model is None or feature_names is None:
        raise HTTPException(
            status_code=503,
            detail="CyberShield models are not loaded. Check ml/models.",
        )

    missing_features = [name for name in feature_names if name not in request.features]
    if missing_features:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "Required CIC-IDS2017 features are missing.",
                "missing_features": missing_features,
                "required_feature_count": len(feature_names),
            },
        )

    try:
        values = []
        for name in feature_names:
            value = request.features[name]
            if value is None:
                raise ValueError(f"Feature '{name}' is null.")
            values.append(float(value))

        input_data = pd.DataFrame([values], columns=feature_names)
        binary_pred = int(binary_model.predict(input_data)[0])
        probabilities = binary_model.predict_proba(input_data)[0]
        binary_classes = list(binary_model.classes_)
        attack_probability = float(probabilities[binary_classes.index(1)])
        threshold = float(binary_bundle.get("threshold", 0.1))
        is_attack = attack_probability >= threshold

        if is_attack:
            threat_probabilities = threat_model.predict_proba(input_data)[0]
            threat_index = int(threat_probabilities.argmax())
            predicted_threat = str(threat_model.classes_[threat_index])
            threat_confidence = float(threat_probabilities[threat_index]) * 100
        else:
            predicted_threat = "BENIGN"
            threat_confidence = None
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Prediction failed: {exc}")

    if not is_attack:
        prediction = "BENIGN"
        severity, risk_score = "Low", 10
    else:
        prediction = predicted_threat
        if attack_probability >= 0.85:
            severity, risk_score = "Critical", 95
        elif attack_probability >= 0.60:
            severity, risk_score = "High", 80
        else:
            severity, risk_score = "Medium", 55

    result = {
        "prediction": prediction,
        "is_attack": bool(is_attack),
        "confidence": round(attack_probability * 100, 2),
        "attack_probability": round(attack_probability * 100, 2),
        "threshold": threshold,
        "predicted_threat": predicted_threat,
        "threat_confidence": round(threat_confidence, 2) if threat_confidence is not None else None,
        "severity": severity,
        "risk_score": risk_score,
        "model": "CyberShield two-stage Random Forest",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    result["id"] = save_prediction(result)
    return result


# --------------------------------------------------
# 12. GET DATASET TEST PAYLOAD
# --------------------------------------------------

@app.get("/api/test-payload")
def get_test_payload():
    payload_path = BASE_DIR / "ml" / "api_test_payload.json"

    if not payload_path.exists():
        raise HTTPException(
            status_code=404,
            detail="Test payload file not found.",
        )

    try:
        with open(payload_path, "r", encoding="utf-8") as file:
            return json.load(file)

    except (OSError, json.JSONDecodeError) as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Could not read test payload: {str(exc)}",
        )


# --------------------------------------------------
# 13. GET PREDICTION HISTORY
# --------------------------------------------------

@app.get("/api/predictions")
def get_prediction_history(limit: int = 100):

    if limit < 1 or limit > 500:
        raise HTTPException(
            status_code=400,
            detail="Limit must be between 1 and 500.",
        )

    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.row_factory = sqlite3.Row

        rows = connection.execute(
            """
            SELECT
                id,
                prediction,
                is_attack,
                confidence,
                severity,
                risk_score,
                model,
                timestamp
            FROM predictions
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    predictions = []

    for row in rows:
        item = dict(row)
        item["is_attack"] = bool(item["is_attack"])
        predictions.append(item)

    return {
        "total": len(predictions),
        "predictions": predictions,
    }